# Dynamic Spot online v5
PREPARING. Same derived heldout episode as v4b. Official Isaac Sim Spot asset and locomotion controller. Native NavMesh audit only; physical triangle mesh contact resolves motion. Root pose initialized once, never overridden during rollout. Camera rigidly mounted [.24,0,.24]m relative to body. Full 6DoF motion. Existing v4b preserved.
